#pragma once


/*
template <class T>
class Singleton
{
	private: 
		static T* instance;

	public:
		static T* getInstance();

	protected: 
		Singleton();
		~Singleton();

	private:
		T(const T&);
		T& operator = (const T&);
};

*/