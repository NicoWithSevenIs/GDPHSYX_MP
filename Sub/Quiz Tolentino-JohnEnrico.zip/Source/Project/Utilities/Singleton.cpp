#include "Singleton.hpp"

/*

template <class T> T* Singleton<T>::instance = nullptr;

template <class T> T* Singleton<T>::getInstance() {
	if (!instance)
		instance = new T();
	return instance;
}
*/