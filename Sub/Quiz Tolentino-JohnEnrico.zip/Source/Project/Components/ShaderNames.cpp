#include "ShaderNames.hpp"


const std::string ShaderNames::MODEL_SHADER = "MODEL_SHADER";
