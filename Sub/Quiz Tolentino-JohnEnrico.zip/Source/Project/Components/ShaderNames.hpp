#pragma once

#include <string>

class ShaderNames {

	public:
		static const std::string MODEL_SHADER;

};